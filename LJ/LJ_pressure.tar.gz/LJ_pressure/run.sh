#!/bin/bash

jupyter nbconvert --ExecutePreprocessor.timeout=0 --to notebook --execute LJ_pressure_NPT1.ipynb &
pid1=$!
jupyter nbconvert --ExecutePreprocessor.timeout=0 --to notebook --execute LJ_pressure_NPT2.ipynb &
pid1=$!
jupyter nbconvert --ExecutePreprocessor.timeout=0 --to notebook --execute LJ_pressure_NPT3.ipynb &
pid1=$!
jupyter nbconvert --ExecutePreprocessor.timeout=0 --to notebook --execute LJ_pressure_NPT4.ipynb &
pid1=$!
jupyter nbconvert --ExecutePreprocessor.timeout=0 --to notebook --execute LJ_pressure_NPT5.ipynb &
pid1=$!
jupyter nbconvert --ExecutePreprocessor.timeout=0 --to notebook --execute LJ_pressure_NPT6.ipynb &
pid1=$!
jupyter nbconvert --ExecutePreprocessor.timeout=0 --to notebook --execute LJ_pressure_NPT7.ipynb &
pid1=$!
jupyter nbconvert --ExecutePreprocessor.timeout=0 --to notebook --execute LJ_pressure_NPT8.ipynb &
pid1=$!
jupyter nbconvert --ExecutePreprocessor.timeout=0 --to notebook --execute LJ_pressure_NPT9.ipynb &
pid1=$!
jupyter nbconvert --ExecutePreprocessor.timeout=0 --to notebook --execute LJ_pressure_NPT10.ipynb &
pid1=$!

wait $pid1 $pid2 $pid3 $pid4 $pid5 $pid6 $pid7 $pid8 $pid9 $pid10

