#PBS -l nodes=1:ppn=1:gpus=1:exclusive_process,mem=1gb
#PBS -S /bin/bash
#PBS -N LJ_data_127
#PBS -j oe
#PBS -o LOG
#PBS -l walltime=48:20:00
module purge
module load devel/cuda/8.0
cd $PBS_O_WORKDIR
make
./out 127
