#!/usr/bin/env python
# coding: utf-8

# In[6]:

import os
import subprocess
from shutil import copyfile


# In[8]:

current=os.getcwd()

for i in range (0,1):
    dir_name="data_"+str(i)
    if os.path.exists(dir_name) is False:
        os.mkdir(dir_name)
    copyfile("LJ_data.cu",dir_name+"/"+"LJ_data.cu")
    copyfile("Makefile",dir_name+"/"+"Makefile")
    with open("tmp.sh",'w') as file:
        file.write("#PBS -l nodes=1:ppn=1:gpus=1:exclusive_process,mem=1gb"+"\n")
        file.write("#PBS -S /bin/bash"+"\n")
        file.write("#PBS -N LJ_data_"+str(i)+"\n")
        file.write("#PBS -j oe\n")
        file.write("#PBS -o LOG\n")
        file.write("#PBS -l walltime=48:20:00\n")
        file.write("module purge\n")
        file.write("module load devel/cuda/8.0\n")
        file.write("cd $PBS_O_WORKDIR\n")
        file.write("make\n")
        file.write("./out "+str(i)+"\n")
    copyfile("tmp.sh",dir_name+"/"+"run_cluster.sh")
    os.chdir(dir_name)
    subprocess.call("qsub -q gpu run_cluster.sh",shell=True)
    #subprocess.call("qsub -q tiny run_cluster.sh",shell=True)
    print(os.getcwd())
    os.chdir(current)
    print(os.getcwd())

